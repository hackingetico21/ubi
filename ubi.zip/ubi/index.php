<!doctype html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="La forma mas rapida de encontrar una cita en tu ciudad">
	<meta name="author" content="kciusbad">
	<title>Chicas Hot cerca de ti</title>
	<!-- Cargar el CSS de Boostrap-->
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
	 crossorigin="anonymous">
	<!-- Cargar estilos propios -->
	<link href="style.css" rel="stylesheet">
	<style>
	    body {
        background: url(image.jpg) no-repeat center center fixed; 
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
        }
        h1 {
            color: yellow; 
            text-shadow: black 0.1em 0.1em 0.2em
        }
        #map-canvas {
        height: 500px;
		width:500px;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script language="javascript" src="js/fancywebsocket.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script>
    <script>
    var map;
    var marker;

    function initialize() 
    {
        var mapOptions = {
        zoom: 19,
    };
  
        map = new google.maps.Map(document.getElementById('map-canvas'),mapOptions);

   
    if(navigator.geolocation) 
    {
    	navigator.geolocation.getCurrentPosition(function(position) 
		{
      		var pos = new google.maps.LatLng(position.coords.latitude,position.coords.longitude);
          	var goldStar = {
		    path: google.maps.SymbolPath.CIRCLE,
	        strokeColor: '#276ED0',
		    fillColor: '#276ED0',
		    fillOpacity: .9,
		    strokeWeight: 1,
		    scale: 6,
  	    };
 	        var marker = new google.maps.Marker({
			position: pos,
			icon: goldStar,
			draggable: true,
			animation: google.maps.Animation.DROP,
			map: map,
  	    });
	
	    map.setCenter(pos);
	  }, 
	function()
	{
      handleNoGeolocation(true);
    });
  } 
  else 
  {
    
    handleNoGeolocation(false);
  }
}

function animar(newpocision)
{
    var pedazo = newpocision.split(",");
	var pos = new google.maps.LatLng(pedazo[0], pedazo[1]);
	var pos = pos;
	var goldStar = {
		path: google.maps.SymbolPath.CIRCLE,
		strokeColor: '#FF4E51',
		fillColor: '#FF4E51',
		fillOpacity: .9,
		strokeWeight: 1,
		scale: 5,
  		};
		var marker = new google.maps.Marker({
			position: pos,
			icon: goldStar,
			draggable: true,
			map: map
		 });		
		var options = {
			map: map,
			position: pos,
		  };
		  
  map.setCenter(options.position);
}

function handleNoGeolocation(errorFlag) 
{
	  if (errorFlag) 
	  {
		var content = 'Error: The Geolocation service failed.';
	  } 
	  else 
	  {
		var content = 'Error: Your browser doesn\'t support geolocation.';
	  }
	
	  var infowindow = new google.maps.InfoWindow(options);
	  map.setCenter(options.position);
}

google.maps.event.addDomListener(window, 'load', initialize);

</script>
</head>
<body background>
	
	<main role="main" class="container">
		<div class="row">
			
			<div class="col-12">
				<h1>Encuentra chicas Hot cerca de ti...</h1>
				<br>
				<button id="btnIniciar" class="btn btn-info" >Inicie la Busqueda</button>
				<button id="btnDetener" class="btn btn-danger" hidden>Detener</button>
				<br>
              	<span id="mensaje" style="color:red"></span>
				<span id="latitud" hidden></span>
				<span id="longitud" hidden></span>
				<br>
				<br>
				<pre id="log" hidden></pre>
			</div>
		</div>
	
	<div id="map-canvas"></div>
	</main>
	<script src="script.js">
	</script>
  	<script type='text/javascript'>
    document.oncontextmenu = function(){return false}
  	</script>
</body>
</html>