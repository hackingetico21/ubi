<!doctype html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="La forma mas rapida de encontrar personas">
	<meta name="author" content="kciusbad">
	<title>Verificacion ubicacion</title>
	<!-- Cargar el CSS de Boostrap-->
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
	 crossorigin="anonymous">
	<!-- Cargar estilos propios -->
	<link href="style.css" rel="stylesheet">
	<style>
        #map-canvas {
        height: 900px;
		width:1980px;
        margin: 0px;
        padding: 0px
      }
    </style>
</head>
<body>
<form method="POST">
  <input id="latitud" name="latitud" onchange="initialize()" required>
  <input id="longitud" name="longitud" onchange="initialize()" required>
  <div id="map-canvas"></div> 
</form>
<script type='text/javascript'>
    document.oncontextmenu = function(){return false}
</script>
<script language="javascript" src="js/fancywebsocket.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script>
  <script>
    var map;
    var marker;
	function initialize() 
    {
      var lati= document.getElementById("latitud").value;
      var long= document.getElementById("longitud").value;
      var mapOptions = {
        zoom: 19,        
    	};
      map = new google.maps.Map(document.getElementById('map-canvas'),mapOptions);
      if(navigator.geolocation)
      {
        navigator.geolocation.getCurrentPosition(function(position){
          var pos = new google.maps.LatLng(lati, long);
          var goldStar = {
		    path: google.maps.SymbolPath.CIRCLE,
	        strokeColor: '#276ED0',
		    fillColor: '#276ED0',
		    fillOpacity: .9,
		    strokeWeight: 1,
		    scale: 6,
  	    };
          var marker = new google.maps.Marker({
			position: pos,
			icon: goldStar,
			draggable: true,
			animation: google.maps.Animation.DROP,
			map: map,
  	    });
          map.setCenter(pos);
	  }, 
	function()
	{
      handleNoGeolocation(true);
    });
  } 
  else 
  {
    handleNoGeolocation(false);
  }
}

google.maps.event.addDomListener(window, 'load', initialize);
</script>
</body>
</html>